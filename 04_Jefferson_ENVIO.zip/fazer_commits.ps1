﻿# Jefferson — audio. Rodar DENTRO de Endless_runner-Metamorfose (depois do Wesley)
$ErrorActionPreference = "Stop"
$env:PATH = "C:\Program Files\Git\cmd;C:\Program Files\Git\bin;" + $env:PATH

$repo = (Get-Location).Path
# Resolve pasta do pacote a partir deste script
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pacote = Join-Path $scriptDir "arquivos"
if (-not (Test-Path $pacote)) {
  Write-Host "Pasta arquivos nao encontrada ao lado do script: $scriptDir" -ForegroundColor Red
  exit 1
}

function Commit-Step($paths, $message) {
  git add -- $paths
  $status = git status --porcelain
  if (-not $status) {
    Write-Host "Nada novo para: $message" -ForegroundColor Yellow
    return
  }
  git commit -m $message
  Write-Host "OK: $message" -ForegroundColor Green
}

Write-Host "== Pull ==" -ForegroundColor Cyan
git pull origin main

Write-Host "== Copiando arquivos ==" -ForegroundColor Cyan
Copy-Item -Path (Join-Path $pacote "*") -Destination $repo -Recurse -Force

Write-Host "== Commits ==" -ForegroundColor Cyan

Commit-Step @("Assets/Resources.meta", "Assets/Resources/Sounds.meta") `
  "chore(audio): criar pasta de recursos sonoros"

Commit-Step @("Assets/Resources/Sounds/Acerto.wav", "Assets/Resources/Sounds/Acerto.wav.meta") `
  "feat(audio): adicionar efeito sonoro de acerto"

Commit-Step @("Assets/Resources/Sounds/Pular.wav", "Assets/Resources/Sounds/Pular.wav.meta") `
  "feat(audio): adicionar efeito sonoro de pulo"

Commit-Step @("Assets/Resources/Sounds/Transformar.wav", "Assets/Resources/Sounds/Transformar.wav.meta") `
  "feat(audio): adicionar efeito sonoro de transformacao"

Commit-Step @("Assets/Resources/Sounds/GameOver.wav", "Assets/Resources/Sounds/GameOver.wav.meta") `
  "feat(audio): adicionar efeito sonoro de game over"

Write-Host "== Push ==" -ForegroundColor Cyan
git push origin main
Write-Host "Concluido. Avise Claudio para rodar a Parte B." -ForegroundColor Green

