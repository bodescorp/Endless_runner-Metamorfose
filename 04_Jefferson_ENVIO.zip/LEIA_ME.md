﻿# Seu pacote — Endless Runner Metamorfose

## Antes de tudo
1. Tenha acesso ao repo: https://github.com/bodescorp/Endless_runner-Metamorfose
2. Clone (se ainda nao tiver):

```powershell
$env:PATH = "C:\Program Files\Git\cmd;" + $env:PATH
cd PASTA_ONDE_QUISER
git clone git@github.com:bodescorp/Endless_runner-Metamorfose.git
```

3. Configure SUA conta GitHub (obrigatorio — o commit fica no seu nome):

```powershell
cd Endless_runner-Metamorfose
git config user.name "SEU_USER_GITHUB"
git config user.email "SEU_EMAIL_GITHUB"
```

## Como usar este ZIP
1. Extraia este ZIP
2. Espere sua vez na ordem da equipe
3. Abra PowerShell na pasta do repo `Endless_runner-Metamorfose`
4. Rode o script indicado abaixo (ajuste o caminho se extraiu em outro lugar)

## Voce: Jefferson (audio)

**Ordem:** 4o — so depois do Wesley

```powershell
powershell -ExecutionPolicy Bypass -File "CAMINHO\DESTE_ZIP\fazer_commits.ps1"
```

Avise o Claudio para rodar a Parte B.
