# Jefferson — Áudio

**Quando:** 4º da fila (depois do Wesley).  
**De onde copiar:** pasta `arquivos\` → raiz de `Endless_runner-Metamorfose\`

```powershell
git pull origin main
# copiar tudo de arquivos\ para a raiz do repo
```

---

## Commit 1 — pasta de sons

**Arquivos:**
- `Assets\Resources.meta` (só se ainda não existir — Claudio já deve ter enviado)
- `Assets\Resources\Sounds.meta` (se existir no pacote)

```powershell
git add Assets/Resources.meta Assets/Resources/Sounds.meta
git commit -m "chore(audio): criar pasta de recursos sonoros"
git push origin main
```

Se o `git status` mostrar que `Resources.meta` não mudou, pule este commit e vá ao próximo.

---

## Commit 2 — efeito de acerto

```powershell
git add Assets/Resources/Sounds/Acerto.wav Assets/Resources/Sounds/Acerto.wav.meta
git commit -m "feat(audio): adicionar efeito sonoro de acerto"
git push origin main
```

---

## Commit 3 — efeito de pulo

```powershell
git add Assets/Resources/Sounds/Pular.wav Assets/Resources/Sounds/Pular.wav.meta
git commit -m "feat(audio): adicionar efeito sonoro de pulo"
git push origin main
```

---

## Commit 4 — efeito de transformação

```powershell
git add Assets/Resources/Sounds/Transformar.wav Assets/Resources/Sounds/Transformar.wav.meta
git commit -m "feat(audio): adicionar efeito sonoro de transformacao"
git push origin main
```

---

## Commit 5 — efeito de game over

```powershell
git add Assets/Resources/Sounds/GameOver.wav Assets/Resources/Sounds/GameOver.wav.meta
git commit -m "feat(audio): adicionar efeito sonoro de game over"
git push origin main
```

> Avisar o Claudio para fazer os commits finais (shaders, cenas, docs).
