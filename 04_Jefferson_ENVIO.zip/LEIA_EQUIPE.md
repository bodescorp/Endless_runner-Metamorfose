# Como cada um contribui (modo fácil)

Repo: `Endless_runner-Metamorfose`  
Pacotes: pasta `_pacotes_commits`

## Ordem (obrigatória)

1. Claudio → roda **parte A**
2. Glaymar
3. Wesley
4. Jefferson
5. Claudio → roda **parte B**

Cada um só começa depois do anterior avisar que deu push.

## O que cada um faz (3 passos)

1. Clonar/abrir o repo e entrar na pasta  
   `Modulo2\Endless_runner-Metamorfose`
2. Configurar a **própria** conta GitHub (uma vez):

```powershell
$env:PATH = "C:\Program Files\Git\cmd;" + $env:PATH
git config user.name "SeuNomeNoGitHub"
git config user.email "seu-email@do-github.com"
```

3. Rodar o script da sua pasta, **na pasta do repo**:

```powershell
# exemplo Glaymar:
powershell -ExecutionPolicy Bypass -File "..\_pacotes_commits\02_Glaymar\fazer_commits.ps1"
```

O script copia os arquivos, faz os commits e dá push.

## Scripts

| Pessoa | Script |
|--------|--------|
| Claudio (1º) | `01_Claudio\fazer_commits_parte_A.ps1` |
| Glaymar | `02_Glaymar\fazer_commits.ps1` |
| Wesley | `03_Wesley\fazer_commits.ps1` |
| Jefferson | `04_Jefferson\fazer_commits.ps1` |
| Claudio (último) | `01_Claudio\fazer_commits_parte_B.ps1` |

Se der erro de `git` não encontrado, feche e abra o terminal de novo, ou use o comando do `$env:PATH` acima.
